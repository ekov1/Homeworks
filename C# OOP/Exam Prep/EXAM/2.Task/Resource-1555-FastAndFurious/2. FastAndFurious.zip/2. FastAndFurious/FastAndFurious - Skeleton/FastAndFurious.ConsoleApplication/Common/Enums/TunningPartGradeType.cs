﻿namespace FastAndFurious.ConsoleApplication.Common.Enums
{
    public enum TunningGradeType
    {
        NotSet = 0,
        LowGrade,
        MidGrade,
        HighGrade
    }
}
