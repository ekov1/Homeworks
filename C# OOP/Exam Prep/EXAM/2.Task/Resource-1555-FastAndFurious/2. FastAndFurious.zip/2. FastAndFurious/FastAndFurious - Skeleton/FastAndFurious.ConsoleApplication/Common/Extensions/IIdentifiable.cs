﻿namespace FastAndFurious.ConsoleApplication.Common.Extensions
{
    internal interface IIdentifiable
    {
        public virtual TEntity GetById(TId id)
        {
            return context.Set<TEntity>().SingleOrDefault(x => x.Id == id);
        }
    }
}